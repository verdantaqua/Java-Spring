package com.spring.fileDown;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.URLEncoder;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.util.FileCopyUtils;
import org.springframework.web.servlet.view.AbstractView;

public class FileDownloadView extends AbstractView{
	
	public FileDownloadView(){
		setContentType("application/download; charset=utf-8");
	}
	
	@Override
	protected void renderMergedOutputModel(Map<String, Object> model,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		// TODO Auto-generated method stub
		
		System.out.println("renderMergedOutputModel() ȣ��");
		
		File file = new File("c:\\uploadFile\\�Լ�.html");//��������\\�ΰ��θ����ش�
		
		response.setContentType(getContentType()); //MIME Ÿ���� ����, ĳ���� ���ڵ� ����
		response.setContentLength(100); //������ ũ��
		
		String userAgent = request.getHeader("User-Agent"); 
		String fileName = null;
		
		if(userAgent.indexOf("MSIE") > -1){//�ͽ��÷ξ� ����κг��� MSIE
			fileName = URLEncoder.encode(file.getName(), "utf-8");//�ѱ۱�������
		}else{
			fileName = new String(file.getName().getBytes("utf-8"), "iso-8859-1");
		}
		
		response.setHeader("Content-Disposition", "attachment; filename=\""+fileName+"\";");
		//�ѱ��� �������Ȱ� �����ϴ±�� <\""==esc�� �����ȵ���>
		response.setHeader("Content-Transfer-Encoding", "binary");
		
		OutputStream out = response.getOutputStream();
		FileInputStream fin = null;
		
		try{
			fin = new FileInputStream(file);
			FileCopyUtils.copy(fin, out);
		}finally{
			if(fin !=null){
				try{
					fin.close();
				}catch(IOException e){
					System.out.println("exception : " + e.toString());
				}
			}
		}//finally
		
		out.flush();
	}
}
