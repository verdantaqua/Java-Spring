package com.javalec.ex;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

public class MainClass {

	public static void main(String[] args) {
		
		AbstractApplicationContext ctx = new GenericXmlApplicationContext("classpath:applicationCTX.xml");
		
		Student student = ctx.getBean("student", Student.class);
		student.getStudentInfo();
		
		Worker worker = ctx.getBean("worker", Worker.class);
		worker.getWorkerInfo();
		
		ctx.close();		
	}//aop aspect maven di���� ���ּ���	
}
//C:\Users\icia02\.m2\repository\org\aspectj\aspectjweaver\1.7.4\aspectjweaver-1.7.1.jar
//�� ��ġ�� �ڵ����� �ٿ�ȴ�