package com.spring.ormEx;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/Person")
public class PersonController {
	@RequestMapping("/personJoin")
	public void personForm(PersonVO personVO){	
			
	}
	
}
