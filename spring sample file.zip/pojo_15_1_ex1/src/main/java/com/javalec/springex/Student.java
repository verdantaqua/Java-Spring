package com.javalec.springex;

public class Student {

	private String name;//null
	private int id;//0
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
}//�� --> Ŀ�ǵ尴ü -->��Ʈ�ѷ� --> ��
//                Validator(����)