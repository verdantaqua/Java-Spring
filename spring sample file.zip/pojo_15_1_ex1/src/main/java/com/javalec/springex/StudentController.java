package com.javalec.springex;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class StudentController {

	@RequestMapping("/studentForm")
	public String studentForm() {
		//http://localhost:8181/pojo_15_1_ex1/studentForm����
		return "createPage";
	}
	
	@RequestMapping("/student/create")
	public String studentCreate(@ModelAttribute("student") Student student, BindingResult result) {
		
		String page = "createDonePage";//createDonePage.jsp��
		
		StudentValidator validator = new StudentValidator();
		validator.validate(student, result);//��ȿ���˻縦�Ѵ�
		if(result.hasErrors()) {
			page = "createPage";//������ �մٸ� �ٽ� ȸ��������������
		}		
		return page;
	}
}
