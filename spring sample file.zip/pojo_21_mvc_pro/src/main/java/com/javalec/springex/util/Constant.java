package com.javalec.springex.util;

import org.springframework.jdbc.core.JdbcTemplate;

public class Constant {

	public static JdbcTemplate template;
	
}
