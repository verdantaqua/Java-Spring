package com.javalec.ex_01;

public class PlayerInfo {
	public Player player;
	
	public PlayerInfo(){} 
	
	public void setPlayer(Player player){
		this.player = player;
	}
	
	public Player getPlayer(){
		return player;
	}
}
