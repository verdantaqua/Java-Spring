package com.spring.fileDown;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.URLEncoder;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.util.FileCopyUtils;
import org.springframework.web.servlet.view.AbstractView;

public class FileDownloadView extends AbstractView{
	
	public FileDownloadView(){
		setContentType("application/download; charset=utf-8");
	}
	
	@Override
	protected void renderMergedOutputModel(Map<String, Object> model,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		// TODO Auto-generated method stub
		
		System.out.println("renderMergedOutputModel() 호출");
		
		File file = new File("c:\\uploadFile\\파일질라.txt");//역슬래쉬\\두개로막아준다
		
		response.setContentType(getContentType()); //MIME 타입을 지정, 캐릭터 인코딩 지정
		response.setContentLength(100); //파일의 크기
		
		String userAgent = request.getHeader("User-Agent");
		String fileName = null;
		
		if(userAgent.indexOf("MSIE") > -1){//익스플로어 헤더부분내용 MSIE
			fileName = URLEncoder.encode(file.getName(), "utf-8");//한글깨짐방지
		}else{
			fileName = new String(file.getName().getBytes("utf-8"), "iso-8859-1");
		}
		
		response.setHeader("Content-Disposition", "attachment; filename=\""+fileName+"\";");
		//한글이 깨지지안고 유지하는기능 <\""==esc가 먹지안도록>
		response.setHeader("Content-Transfer-Encoding", "binary");
		
		OutputStream out = response.getOutputStream();
		FileInputStream fin = null;
		
		try{
			fin = new FileInputStream(file);
			FileCopyUtils.copy(fin, out);
		}finally{
			if(fin !=null){
				try{
					fin.close();
				}catch(IOException e){
					System.out.println("exception : " + e.toString());
				}
			}
		}//finally
		
		out.flush();
	}
}
